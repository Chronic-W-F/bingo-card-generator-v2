export const metadata = {
  applicationName: "Grower Bingo",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Grower Bingo",
  },
  formatDetection: {
    telephone: false,
  },
};
